
#ifndef CELL_H
#define CELL_H

class Cell {
public:
    bool alive;
    Cell() : alive(false) {}
};

#endif // CELL_H

// Universe.h
#ifndef UNIVERSE_H
#define UNIVERSE_H

#include <vector>
#include <string>
#include "Cell.h" // Включаем Cell.h

class Universe {
private:
    std::vector<std::vector<Cell>> grid;
    int width;
    int height;
    std::string rule;
    std::string name;

public:
    Universe(int width, int height);
    void loadFromFile(const std::string &filename);
    void update();
    void display() const;