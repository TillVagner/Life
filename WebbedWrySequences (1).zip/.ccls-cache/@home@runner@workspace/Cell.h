#ifndef CELL_H
#define CELL_H

class Cell {
public:
    bool alive; // Состояние клетки

    Cell() : alive(false) {} // Конструктор по умолчанию
};

#endif // CELL_H
