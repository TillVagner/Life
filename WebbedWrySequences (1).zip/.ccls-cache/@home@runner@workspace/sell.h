
#ifndef CELL_H
#define CELL_H

class Cell {
public:
    bool alive;
    Cell() : alive(false) {}
};

#endif
