#include "Game.h"
#include <iostream>
#include <cstring>

int main(int argc, char *argv[]) {
    std::string filename;
    int width = 10;
    int height = 10;

    // Обработка аргументов командной строки
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-i") == 0 || strcmp(argv[i], "--iterations") == 0) {
            // Здесь можно добавить обработку количества итераций в Game.
        } else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--output") == 0) {
            // Обработка выходного файла здесь.
        } else {
            filename = argv[i]; 
        }
    }

    Game game(width, height); // Создаем игру
    if (!filename.empty()) {
        game.loadFromFile(filename); // Загружаем вселенную из файла
    } else {
        // Если файл не задан, можно инициализировать произвольное поле по умолчанию или заранее заданное.
        // Для демонстрации можно использовать известную конфигурацию.
        // Например, можно загрузить заранее подготовленный файл.
    }

    game.run(); // Запускаем игру
    return 0;
}
